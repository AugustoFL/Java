
public class Principal {

    public static void main(String[] args) {
        Aluno al = new Aluno();
        al.preencher();
        al.exibir();
        al.calcularMedia();

        Aluno al2 = new Aluno();

    }
}
