package Exercicio1;

import javax.swing.JOptionPane;

public class Cliente {

    private String nome;
    private String cpf;

    private double salario;

    public void preencher() {
        nome = JOptionPane.showInputDialog("Digite seu nome:");
        cpf = JOptionPane.showInputDialog("Digite seu CPF:");

        salario = Double.parseDouble(JOptionPane.showInputDialog("Digite seu salario:"));
    }

public void exibir() {
        JOptionPane.showMessageDialog(null, "Nome: " + nome + "\nCPF: "
                + cpf + "\nSalario: "
                + salario + "\n");
    }
}
