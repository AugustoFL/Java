package Exercicio1;

public class PrincipalExercicio1 {

    public static void main(String[] args) {
        Cliente cl = new Cliente();

        cl.preencher();
        cl.exibir();
    }
}
