
import javax.swing.JOptionPane;

public class Aluno {

    //Atributos
    private String nome;
    private String ra;
    private String curso;

    private double nota1;
    private double nota2;

//Metodos
    public void preencher() {
        nome = JOptionPane.showInputDialog("Nome:");
        ra = JOptionPane.showInputDialog("RA:");
        curso = JOptionPane.showInputDialog("Curso:");
        nota1 = Double.parseDouble(JOptionPane.showInputDialog("Nota 1:"));
        nota2 = Double.parseDouble(JOptionPane.showInputDialog("Nota 2:"));
    }

    public void exibir() {
        JOptionPane.showMessageDialog(null, "Nome: " + nome + "\nRA: "
                + ra + "\nCurso: "
                + curso + "\nNota1: "
                + nota1 + "\nNota2 :"
                + nota2 + "\n");
    }

    public void calcularMedia() {
        double media;
        media = (nota1 + nota2) / 2;
        JOptionPane.showMessageDialog(null, "Media do aluno " + nome + ": " + media);
    }
}
