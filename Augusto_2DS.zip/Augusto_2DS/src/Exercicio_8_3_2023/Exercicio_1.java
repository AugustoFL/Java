/*
1.Fazer um algoritmo que leia um número inteiro e escreva o seu antecessor e o seu sucessor. 
 */
package Exercicio_8_3_2023;

import javax.swing.JOptionPane;

public class Exercicio_1 {

    public static void main(String[] args) {
        int x, antecessor, sucessor;
        x = Integer.parseInt(JOptionPane.showInputDialog("Digite um número, iremos ver o seu antecessor e o seu sucessor"));
        antecessor = x - 1;
        sucessor = x + 1;
        JOptionPane.showMessageDialog(null, antecessor + " é antecessor e o sucessor é: " + sucessor);
    }
}
