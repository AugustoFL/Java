/*
7.Elabore um algoritmo que dada a idade de um nadador classifica-o em uma das seguintes categorias: 
Infantil A = 5 - 7 anos 
Infantil B = 8-10 anos 
Juvenil A = 11-13 anos 
Juvenil B = 14-17 anos 
Adulto = maiores de 18 anos 

 */
package Exercicio_8_3_2023;

import javax.swing.JOptionPane;

public class Exercicio_7 {

    public static void main(String[] args) {

        int idade;

        idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a idade do nadador"));

        if (idade < 5) {
            JOptionPane.showMessageDialog(null, "Muito novo! \nEncerando o programa...");
            System.exit(0);
        } else if (idade >= 5 && idade <= 7) {
            JOptionPane.showMessageDialog(null, "Visto que está entre 5 a 7 anos, o nadador"
                    + " se qualifica para a categoria: 'Infantil A' ");
        } else if (idade >= 8 && idade <= 10) {
            JOptionPane.showMessageDialog(null, "Visto que está entre 8 a 10 anos, o nadador"
                    + " se qualifica para a categoria: 'Infantil B' ");
        } else if (idade >= 11 && idade <= 13) {
            JOptionPane.showMessageDialog(null, "Visto que está entre 11 a 13 anos, o nadador"
                    + " se qualifica para a categoria: 'Juvenil A' ");
        } else if (idade >= 14 && idade <= 17) {
            JOptionPane.showMessageDialog(null, "Visto que está entre 14 a 17 anos, o nadador"
                    + " se qualifica para a categoria: 'Juvenil B' ");
        } else if (idade >= 18) {
            JOptionPane.showMessageDialog(null, "Visto que tem 18 ou é maior, o nadador"
                    + " se qualifica para a categoria: 'Adulto' ");
        }
    }
}
