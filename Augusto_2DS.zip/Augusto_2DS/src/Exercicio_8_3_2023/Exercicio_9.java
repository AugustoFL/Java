/*
9.Fazer um programa para encontrar todos os pares entre 1 e 38. 
 */
package Exercicio_8_3_2023;

import javax.swing.JOptionPane;

public class Exercicio_9 {

    public static void main(String[] args) {

        JOptionPane.showMessageDialog(null, "Vamos imprimir os pares entre 1 e 38");

        for (int i = 2; i <= 38; i = i + 2) {
            JOptionPane.showMessageDialog(null, i);
        }
    }
}
