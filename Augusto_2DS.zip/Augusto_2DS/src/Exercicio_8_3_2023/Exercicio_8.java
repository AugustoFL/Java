/*
8.Exibir os números de 1 até 50 na tela. 
 */
package Exercicio_8_3_2023;

import javax.swing.JOptionPane;

public class Exercicio_8 {

    public static void main(String[] args) {

        JOptionPane.showMessageDialog(null, "Vamos imprimir valor de 1 até 50...");

        for (int i = 1; i < 51; i++) {
            JOptionPane.showMessageDialog(null, i);
        }
    }
}
