/*
6.Ler as notas da 1a. e 2a. avaliações de um aluno. 
Calcular a média aritmética simples e escrever uma mensagem que diga se o aluno foi ou não aprovado 
(considerar que nota igual ou maior que 6 o aluno é aprovado). 
Escrever também a média calculada.
 */
package Exercicio_8_3_2023;

import javax.swing.JOptionPane;

public class Exercicio_6 {

    public static void main(String[] args) {

        int a1, a2, media;

        a1 = Integer.parseInt(JOptionPane.showInputDialog("Digite a nota da primeira avaliação"));
        a2 = Integer.parseInt(JOptionPane.showInputDialog("Digite a nota da secunda avaliação"));

        if (a1 > 10 || a2 > 10) {
            JOptionPane.showMessageDialog(null, "Uma ou mais notas invalidas! Encerrando programa..."
                    + "    Por favor, reinicie e tente novamente");
            System.exit(0);
        }

        media = (a1 + a2) / 2;

        JOptionPane.showMessageDialog(null, "A media das notas é: " + media + "   \nSendo assim...");

        if (media >= 6) {
            JOptionPane.showMessageDialog(null, "O aluno foi aprovado! ^^");
        } else if (media <= 5) {
            JOptionPane.showMessageDialog(null, "O aluno foi reprovado...   :(");
        } else {
            JOptionPane.showMessageDialog(null, "Invalido, reinicie o progarama e tente novamente");
        }
    }
}
