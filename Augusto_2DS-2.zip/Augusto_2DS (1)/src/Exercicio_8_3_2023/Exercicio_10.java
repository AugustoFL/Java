/*
10.Ler 2 valores, calcular e escrever a soma dos inteiros existentes entre os 2 
valores lidos (incluindo os valores lidos na soma). Considere que o segundo valor
lido será sempre maior que o primeiro valor lido. 
 */
package Exercicio_8_3_2023;

import javax.swing.JOptionPane;

public class Exercicio_10 {

    public static void main(String[] args) {

        int n[] = new int[2];
        int soma= 0;

        JOptionPane.showMessageDialog(null, "Vamos somar todos os numeros entre o inter"
                + "valo de dois numeros escolhidos");
        n[0] = Integer.parseInt(JOptionPane.showInputDialog("Digite o primeiro número: "));
        n[1] = Integer.parseInt(JOptionPane.showInputDialog("Digite o segundo número ("
                + "Deve ser maior que o primeiro)"));
        if (n[0] > n[1]) {
            JOptionPane.showInputDialog(null, "Segundo número é menor que o primeiro, inva"
                    + "lido! Encerrando/Reiniciando o programa...");
            System.exit(0);
        }
        else {
         for (int cont = 0; cont <= n[1]; cont++){
soma = cont+soma;
JOptionPane.showMessageDialog(null, soma+"   Resultado total");
}
        }
    }
}
