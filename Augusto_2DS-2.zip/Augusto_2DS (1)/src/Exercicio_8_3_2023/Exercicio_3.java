/*
3. O custo de um carro novo ao consumidor é a soma do custo de fábrica com
 a porcentagem do distribuidor e dos impostos (aplicados ao custo de fábrica). 
Supondo que o percentual do distribuidor seja de 28% e os impostos de 45%,
 escrever um algoritmo para ler o custo de fábrica de um carro, calcular e 
 escrever o custo final ao consumidor.
 */
package Exercicio_8_3_2023;

import javax.swing.JOptionPane;

public class Exercicio_3 {

    public static void main(String[] args) {

        double distri, impo, fab;

        fab = Double.parseDouble(JOptionPane.showInputDialog("Digite o preço de fabrica do carro:"));
        impo = fab * 0.45;
        distri = fab * 0.28;

        JOptionPane.showMessageDialog(null, fab + " é o custo de fabricação, " + impo + " o custo de impostos, " + distri
                + " o custo da distribuição, o preço final"
                + " total ao consumidor é: " + (fab + impo + distri));

    }
}
