/*
2. Ler uma medida em polegadas e imprimir a equivalente em centímetros, sabendo 
    que 2.54 cm equivale a 1 polegada. 
 */
package Exercicio_8_3_2023;

import javax.swing.JOptionPane;

public class Exercicio_2 {

    public static void main(String[] args) {

        double n;

        n = Double.parseDouble(JOptionPane.showInputDialog("Digite um numero em polegadas, iremos converter para centimetros"));
        JOptionPane.showMessageDialog(null, n + " polegadas em centimetros é equivalente a: " + (n * 2.54) + " centimetros");
    }
}
