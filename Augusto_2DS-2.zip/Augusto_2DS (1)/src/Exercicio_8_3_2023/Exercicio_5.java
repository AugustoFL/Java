/*
5.As maçãs custam R$ 1,30 cada se forem compradas menos de uma dúzia, e R$ 1,00 se forem compradas pelo menos 12. 
Escreva um programa que leia o número de maçãs compradas, calcule e escreva o custo total da compra.
 */
package Exercicio_8_3_2023;

import javax.swing.JOptionPane;

public class Exercicio_5 {

    public static void main(String[] args) {

        double maca;

        maca = Double.parseDouble(JOptionPane.showInputDialog("Quantas maças você quer comprar?"));

        if (maca < 12) {
            maca = maca * 1.30;
            JOptionPane.showMessageDialog(null, "Sua compra será no valor total de: " + maca + " reais");
        } else if (maca >= 12) {
            maca = maca * 1.00;
            JOptionPane.showMessageDialog(null, "Sua compra será no valor total de: " + maca + " reais");
        } else {
            JOptionPane.showMessageDialog(null, "Invalido, reinicie o programa e tente novamente");
        }
    }
}
