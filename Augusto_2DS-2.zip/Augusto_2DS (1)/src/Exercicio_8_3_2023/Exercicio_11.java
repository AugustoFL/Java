/*
11.Chico tem 1,50m e cresce 2 centímetros por ano, enquanto Juca tem 1,10m
e cresce 3 centímetros por ano. Construir um algoritmo que calcule e imprima 
quantos anos serão necessários para que Juca seja maior que Chico.
 */
package Exercicio_8_3_2023;

import javax.swing.JOptionPane;

public class Exercicio_11 {

    public static void main(String[] args) {

        double chico = 1.50, juca = 1.10;
        double cresC = 0.2, cresJ = 0.3;
        int anos = 0;

        JOptionPane.showMessageDialog(null, "Chico tem 1,50m e cresce 2 centímetros"
                + " por ano, enquanto Juca tem 1,10m\n e cresce 3 centímetros por ano.\n "
                + "Vamos ver em quantos anos Juca será maior que Chico");

        while (juca < chico) {
            chico = cresC + chico;
            juca = juca + cresJ;
            anos++;
        }
        JOptionPane.showMessageDialog(null, "Levaram " + anos + " para Juca ficar maior"
                + " que Chico");
    }
}
