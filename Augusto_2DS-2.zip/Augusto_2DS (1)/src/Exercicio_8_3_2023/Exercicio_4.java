/*
4.Faça um algoritmo para ler dois números inteiros e informar se estes são iguais ou diferentes.
 */
package Exercicio_8_3_2023;

import javax.swing.JOptionPane;

public class Exercicio_4 {

    public static void main(String[] args) {

        int n[] = new int[2];

        n[0] = Integer.parseInt(JOptionPane.showInputDialog("Digite um numero inteiro"));
        n[1] = Integer.parseInt(JOptionPane.showInputDialog("Digite outro número"));

        if (n[0] == n[1]) {
            JOptionPane.showMessageDialog(null, "Os números são iguais");
        } else {
            JOptionPane.showMessageDialog(null, "Os números são diferentes");
        }

    }
}
